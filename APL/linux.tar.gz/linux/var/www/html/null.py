for each in range(1,100):
    print 'The number is', each